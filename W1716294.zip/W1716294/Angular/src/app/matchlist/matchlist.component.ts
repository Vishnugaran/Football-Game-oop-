import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Match } from '../Matchlist';


@Component({
  selector: 'app-matchlist',
  templateUrl: './matchlist.component.html',
  styleUrls: ['./matchlist.component.css']
})
export class MatchlistComponent implements OnInit {
  Matchlist:Match[]=[];
  private httpClient;
  private baseUrl = "http://localhost:9000/sendMatchclubs";

  constructor (httpClient: HttpClient) {
    this.httpClient = httpClient;
  }

  ngOnInit(){
    this.getMList();
  }

  getMatchlist():Observable<Match[]>{
    return this.httpClient.get<Match[]>(`${this.baseUrl}`)
  }

  getMList(){
    this.getMatchlist().subscribe((data:Match[])=>{
      console.log(data);
      this.Matchlist=data;   
    });
  }

}
