export class Date{
    public day:Number=0;
    public month:Number=0;
    public year:Number=0;
}