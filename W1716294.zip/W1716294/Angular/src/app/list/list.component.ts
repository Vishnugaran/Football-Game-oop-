import { Component, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { FootballClub } from '../FootballClub';
import { Observable } from 'rxjs';
import { Match } from '../Matchlist';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
fblist: FootballClub[] = [];

private httpClient;
private baseUrl = "http://localhost:9000/sendclubs";
  
  constructor (httpClient: HttpClient) {
    this.httpClient = httpClient;
  }
  

  ngOnInit() {
    this.getList();
  }

  getlistlist():Observable<FootballClub[]>{
    return this.httpClient.get<FootballClub[]>(`${this.baseUrl}`)
  }

  getList(){
    this.getlistlist().subscribe((data:FootballClub[])=>{
      console.log(data);
      this.fblist=data;   
    });
  }

    


}

              
