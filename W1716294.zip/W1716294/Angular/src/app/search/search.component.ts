import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Match } from '../Matchlist';



@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  Matchlist:Match[]=[];
  searchText: any;
  
  
  private httpClient;
  private baseUrl = "http://localhost:9000/sendMatchclubs";

  constructor (httpClient: HttpClient) {
    this.httpClient = httpClient;
  }

  ngOnInit(){
    this.getMList();
  }

  getMatchlist():Observable<Match[]>{
    return this.httpClient.get<Match[]>(`${this.baseUrl}`)
  }

  getMList(){
    this.getMatchlist().subscribe((data:Match[])=>{
      console.log(data);
      this.Matchlist=data;   
    });
  }
}
