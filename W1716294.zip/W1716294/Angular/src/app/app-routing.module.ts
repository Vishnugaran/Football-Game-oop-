import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GoalComponent } from './goal/goal.component';
import { ListComponent } from './list/list.component';
import { MatchlistComponent } from './matchlist/matchlist.component';
import { PointComponent } from './point/point.component';
import { RandomComponent } from './random/random.component';
import { SearchComponent } from './search/search.component';
import { WinComponent } from './win/win.component';

const routes: Routes =
[{path: 'list', component: ListComponent},
{path: 'matchlist', component: MatchlistComponent},
{path: 'random', component: RandomComponent},
{path: 'posort', component: PointComponent},
{path: 'search',component: SearchComponent},
{path: 'wsort',component: WinComponent},
{path: 'gsort',component: GoalComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
