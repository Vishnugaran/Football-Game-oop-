import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FootballClub } from '../FootballClub';

@Component({
  selector: 'app-goal',
  templateUrl: './goal.component.html',
  styleUrls: ['./goal.component.css']
})
export class GoalComponent implements OnInit {
  glist:FootballClub[]=[];
  private httpClient;

  private Url = "http://localhost:9000/gsort";
    
    constructor (httpClient: HttpClient) {
      this.httpClient = httpClient;
    }
    

  ngOnInit(){
    this.getposort();
  }

  getpointsort():Observable<FootballClub[]>{
    return this.httpClient.get<FootballClub[]>(`${this.Url}`)
  }

  getposort(){
    this.getpointsort().subscribe((data:FootballClub[])=>{
      console.log(data);
      this.glist=data;   
    });

}

}
