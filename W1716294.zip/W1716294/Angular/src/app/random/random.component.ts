import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Match } from '../Matchlist';

@Component({
  selector: 'app-random',
  templateUrl: './random.component.html',
  styleUrls: ['./random.component.css']
})
export class RandomComponent implements OnInit {
  Randlist : any; 
  private httpClient;
  private baseUrl = "http://localhost:9000/random";

  constructor (httpClient: HttpClient) {
    this.httpClient = httpClient;
  }
  
  ngOnInit(){
    this.getrandList();
  }

  getrandomlist():Observable<Match[]>{
    return this.httpClient.get<Match[]>(`${this.baseUrl}`)
  }

  getrandList(){
    this.getrandomlist().subscribe((data:Match[])=>{
      console.log(data);
      this.Randlist=data;   
    });
  }


}
