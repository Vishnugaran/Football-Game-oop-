import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListComponent } from './list/list.component';
import { HomeComponent } from './home/home.component';
import { RandomComponent } from './random/random.component';
import { MatchlistComponent } from './matchlist/matchlist.component';
import { SearchComponent } from './search/search.component';
import { HttpClientModule } from '@angular/common/http';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { PointComponent } from './point/point.component';
import { WinComponent } from './win/win.component';
import { GoalComponent } from './goal/goal.component';
// import { MatDatepickerModule} from '@angular/material/datepicker';
// import { MatNativeDateModule} from '@angular/material/core';




@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    HomeComponent,
    RandomComponent,
    MatchlistComponent,
    SearchComponent,
    PointComponent,
    WinComponent,
    GoalComponent,
    
  
  ],
  imports: [
    Ng2SearchPipeModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    // MatDatepickerModule,
    // MatNativeDateModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
