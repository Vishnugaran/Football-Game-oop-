import {Date} from './Date'

export class FootballClub{
        public clubName:string="";
        public clubId:String="";
        public location:String="";
        public joinDate: String="";
        public matchWins:number=0;
        public matchLose:number=0;
        public matchTies:number=0;
        public goalReceived:number=0;
        public goalScored:number=0;
        public matchesPlayed:number=0; 
        public points:number=0
}
    
