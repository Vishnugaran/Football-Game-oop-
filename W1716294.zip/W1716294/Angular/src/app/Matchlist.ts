import {Date} from './Date'

export class Match{
    public homeTeam:string="";
    public awayTeam:String="";
    public homeGoal:number=0;
    public awayGoal:number=0;
    public date: Date = new Date;
    // public date1:string="";
}